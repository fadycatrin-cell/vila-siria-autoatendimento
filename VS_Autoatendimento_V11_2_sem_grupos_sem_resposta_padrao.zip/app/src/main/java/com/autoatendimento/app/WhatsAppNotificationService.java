package com.autoatendimento.app;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.MediaPlayer;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class WhatsAppNotificationService extends NotificationListenerService {
    private static final String WA = "com.whatsapp";
    private static final String WAB = "com.whatsapp.w4b";
    private static final String HISTORY_KEY = "history";
    private static final long DEDUPE_WINDOW_MS = 12000L;
    private static final long OUTGOING_IGNORE_MS = 30000L;

    private SharedPreferences prefs;
    private final Object lock = new Object();
    private final LinkedHashMap<String, Long> recentProcessed = new LinkedHashMap<>();
    private final LinkedHashMap<String, Long> recentOutgoing = new LinkedHashMap<>();

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("auto_config", MODE_PRIVATE);
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!WA.equals(sbn.getPackageName()) && !WAB.equals(sbn.getPackageName())) return;

        Notification notification = sbn.getNotification();

        // O VS Autoatendimento responde somente conversas individuais.
        // Se o Android identificar a notificação como conversa em grupo,
        // ela é ignorada antes de qualquer processamento ou resposta.
        if (isGroupConversation(notification)) return;

        String text = extractText(notification);
        if (text.trim().isEmpty()) return;

        JSONObject cfg;
        try {
            cfg = new JSONObject(prefs.getString("config", "{}"));
        } catch(Exception e) {
            return;
        }
        if (!cfg.optBoolean("active", false)) return;

        String title = "";
        if (notification.extras != null) {
            title = String.valueOf(notification.extras.getCharSequence(Notification.EXTRA_TITLE, ""));
        }

        final long now = System.currentTimeMillis();
        final String normalizedText = norm(text);
        final String normalizedTitle = norm(title);

        // Importante: a própria resposta enviada pelo app também pode aparecer
        // como uma nova notificação do WhatsApp. Se processarmos essa notificação,
        // o bot pode responder a si mesmo e gerar duplicações/loop.
        synchronized (lock) {
            cleanup(recentOutgoing, now, OUTGOING_IGNORE_MS);
            String outgoingKey = sbn.getPackageName() + "|" + normalizedText;
            if (recentOutgoing.containsKey(outgoingKey)) return;

            cleanup(recentProcessed, now, DEDUPE_WINDOW_MS);
            // Usa a chave nativa da notificação quando disponível e também um
            // fingerprint por contato/texto para cobrir atualizações do WhatsApp
            // que recriam a notificação com outra chave.
            String keyByNotification = sbn.getPackageName() + "|" + sbn.getKey() + "|" + normalizedText;
            String keyByContent = sbn.getPackageName() + "|" + normalizedTitle + "|" + normalizedText;
            if (recentProcessed.containsKey(keyByNotification) || recentProcessed.containsKey(keyByContent)) {
                return;
            }
            recentProcessed.put(keyByNotification, now);
            recentProcessed.put(keyByContent, now);
        }

        String reply = chooseReply(cfg, text);
        if (reply == null || reply.trim().isEmpty()) return;

        final int delaySeconds = Math.max(0, Math.min(60, cfg.optInt("replyDelaySeconds", 0)));
        final String contact = title;
        final String originalText = text;
        final String packageName = sbn.getPackageName();
        Runnable sendTask = () -> {
            boolean sent = sendReply(notification, reply);
            if (sent) {
                synchronized (lock) {
                    String outgoingKey = packageName + "|" + norm(reply);
                    recentOutgoing.put(outgoingKey, System.currentTimeMillis());
                }
                if (cfg.optBoolean("soundEnabled", true)) {
                    playResponseSound(cfg.optInt("soundId", 1), cfg.optInt("soundVolume", 70));
                }
            }
            String historyReply = sent
                    ? reply
                    : "Não foi possível enviar automaticamente pela notificação.";
            appendHistory(contact, originalText, historyReply, sent, delaySeconds);
        };

        if (delaySeconds > 0) {
            new Handler(Looper.getMainLooper()).postDelayed(sendTask, delaySeconds * 1000L);
        } else {
            sendTask.run();
        }
    }

    private boolean isGroupConversation(Notification n) {
        try {
            Bundle e = n.extras;
            if (e == null) return false;

            // Chave oficial usada pelo Android para indicar que a
            // notificação representa uma conversa em grupo.
            return e.getBoolean("android.isGroupConversation", false);
        } catch (Exception ignored) {
            return false;
        }
    }

    private String extractText(Notification n) {
        Bundle e = n.extras;
        if (e == null) return "";

        CharSequence cs = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (cs == null) cs = e.getCharSequence(Notification.EXTRA_TEXT);

        // Em algumas versões do WhatsApp o texto pode vir em linhas.
        if (cs == null) {
            CharSequence[] lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
            if (lines != null && lines.length > 0) {
                StringBuilder b = new StringBuilder();
                for (CharSequence line : lines) {
                    if (line != null) {
                        if (b.length() > 0) b.append("\n");
                        b.append(line);
                    }
                }
                cs = b.toString();
            }
        }
        return cs == null ? "" : cs.toString();
    }

    private String chooseReply(JSONObject c, String msg) {
        // PRIORIDADE ABSOLUTA: fora do horário, somente a mensagem de fora do horário.
        // Nenhuma palavra-chave, boas-vindas ou resposta alternativa é consultada.
        boolean openNow = isOpenNow(c.optJSONObject("schedule"));
        if (!openNow) {
            if (!c.optBoolean("afterHoursEnabled", true)) return "";
            return c.optString("afterHours",
                    "Olá! 😊 No momento estamos fora do nosso horário de funcionamento.");
        }

        String n = norm(msg);
        JSONArray rules = c.optJSONArray("keywords");
        if (rules != null) {
            for (int i = 0; i < rules.length(); i++) {
                try {
                    JSONObject r = rules.getJSONObject(i);
                    JSONArray keys = r.optJSONArray("k");
                    if (keys != null) {
                        for (int j = 0; j < keys.length(); j++) {
                            String key = keys.optString(j);
                            if (!key.trim().isEmpty() && n.contains(norm(key))) {
                                return r.optString("r", "");
                            }
                        }
                    } else {
                        String key = r.optString("k", "");
                        if (!key.trim().isEmpty() && n.contains(norm(key))) {
                            return r.optString("r", "");
                        }
                    }
                } catch(Exception ignored) {}
            }
        }

        // Sem palavra-chave cadastrada: não responde nada.
        // A resposta de fora do horário já foi tratada acima e continua
        // tendo prioridade absoluta quando o estabelecimento está fechado.
        return "";
    }

    private boolean isOpenNow(JSONObject schedule) {
        if (schedule == null) return true;

        String[] days = {"domingo","segunda","terca","quarta","quinta","sexta","sabado"};
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int day = cal.get(java.util.Calendar.DAY_OF_WEEK) - 1;
        String key = days[day];

        JSONArray periods = schedule.optJSONArray(key);
        if (periods == null || periods.length() == 0) return false;

        int mins = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60
                + cal.get(java.util.Calendar.MINUTE);

        for (int i = 0; i < periods.length(); i++) {
            try {
                JSONArray p = periods.getJSONArray(i);
                int a = toMin(p.getString(0));
                int b = toMin(p.getString(1));
                if (b <= a ? (mins >= a || mins < b) : (mins >= a && mins < b)) {
                    return true;
                }
            } catch(Exception ignored) {}
        }
        return false;
    }

    private int toMin(String s) {
        String[] x = s.split(":");
        return Integer.parseInt(x[0]) * 60 + Integer.parseInt(x[1]);
    }

    private String norm(String s) {
        return Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }

    private boolean sendReply(Notification n, String reply) {
        if (n.actions == null) return false;

        for (Notification.Action a : n.actions) {
            RemoteInput[] ris = a.getRemoteInputs();
            if (ris == null || ris.length == 0) continue;

            Intent intent = new Intent();
            Bundle results = new Bundle();
            for (RemoteInput ri : ris) {
                results.putCharSequence(ri.getResultKey(), reply);
            }

            RemoteInput.addResultsToIntent(ris, intent, results);
            try {
                a.actionIntent.send(this, 0, intent);
                return true;
            } catch(Exception ignored) {}
        }
        return false;
    }

    private void cleanup(Map<String, Long> map, long now, long ttl) {
        Iterator<Map.Entry<String, Long>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Long> e = it.next();
            if (now - e.getValue() >= ttl) it.remove();
        }
    }

    private void playResponseSound(int soundId, int volume) {
        try {
            int resId;
            switch(soundId) {
                case 2: resId = R.raw.alerta2; break;
                case 3: resId = R.raw.alerta3; break;
                case 4: resId = R.raw.alerta4; break;
                case 5: resId = R.raw.alerta5; break;
                default: resId = R.raw.alerta1;
            }
            float v = Math.max(0f, Math.min(1f, volume / 100f));
            if (v <= 0f) return;
            MediaPlayer mp = MediaPlayer.create(this, resId);
            if (mp == null) return;
            mp.setVolume(v, v);
            mp.setOnCompletionListener(MediaPlayer::release);
            mp.start();
        } catch(Exception ignored) {}
    }

    private void appendHistory(String contact, String incoming, String reply, boolean sent, int delaySeconds) {
        synchronized (lock) {
            try {
                JSONArray old = new JSONArray(prefs.getString(HISTORY_KEY, "[]"));
                JSONArray out = new JSONArray();

                JSONObject item = new JSONObject();
                item.put("type", "atendimento");
                item.put("contact", contact == null ? "" : contact);
                item.put("incoming", incoming == null ? "" : incoming);
                item.put("reply", reply == null ? "" : reply);
                item.put("sent", sent);
                item.put("delaySeconds", delaySeconds);
                item.put("at", new java.text.SimpleDateFormat(
                        "dd/MM/yyyy HH:mm:ss", Locale.getDefault())
                        .format(new java.util.Date()));

                out.put(item);
                int max = Math.min(old.length(), 199);
                for (int i = 0; i < max; i++) out.put(old.get(i));

                prefs.edit().putString(HISTORY_KEY, out.toString()).apply();
            } catch(Exception ignored) {}
        }
    }
}

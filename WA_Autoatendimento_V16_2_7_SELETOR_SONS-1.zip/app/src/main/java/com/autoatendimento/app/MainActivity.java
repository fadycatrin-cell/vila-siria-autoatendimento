package com.autoatendimento.app;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.widget.Toast;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.View;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PICK_PROFILE_PHOTO = 1001;
    private static final int CREATE_BACKUP = 1002;
    private static final int RESTORE_BACKUP = 1003;
    private static final int PICK_RINGTONE = 1004;
    private String pendingRingtoneCategory = "response";
    private String pendingBackup = "";
    private WebView web;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3001); }
        prefs = getSharedPreferences("auto_config", MODE_PRIVATE);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        // O Android moderno pode desenhar o WebView por baixo da barra de status.
        // Reservamos o espaço da barra para que o topo do Autoatendimento não fique escondido.
        int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarId > 0) {
            int statusBarHeight = getResources().getDimensionPixelSize(statusBarId);
            web.setPadding(0, statusBarHeight, 0, 0);
            web.setClipToPadding(false);
        }
        getWindow().setStatusBarColor(Color.rgb(18, 140, 90));
        getWindow().setNavigationBarColor(Color.rgb(7, 94, 84));
        // Necessário para alert(), prompt() e confirm() funcionarem dentro do WebView.
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_RINGTONE) {
            if (resultCode == RESULT_OK && data != null) {
                Uri picked = data.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                String value = picked == null ? "" : picked.toString();
                prefs.edit().putString("ringtone_" + pendingRingtoneCategory, value).apply();
                String js = "onNativeRingtoneChosen(" + JSONObject.quote(pendingRingtoneCategory) + "," + JSONObject.quote(value) + ")";
                if (web != null) web.post(() -> web.evaluateJavascript(js, null));
            }
            return;
        }
        if (requestCode == CREATE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (java.io.OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) out.write(pendingBackup.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                Toast.makeText(this, "Backup WA salvo.", Toast.LENGTH_LONG).show();
            } catch (Exception e) { Toast.makeText(this, "Não foi possível salvar o backup.", Toast.LENGTH_LONG).show(); }
            pendingBackup = "";
            return;
        }
        if (requestCode == RESTORE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
                if (in == null) throw new java.io.IOException("Arquivo indisponível");
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                byte[] bytes = new byte[8192]; int count;
                while ((count = in.read(bytes)) != -1) buffer.write(bytes, 0, count);
                String json = new String(buffer.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
                if (web != null) web.post(() -> web.evaluateJavascript("restoreBackupFromAndroid(" + JSONObject.quote(json) + ")", null));
            } catch (Exception e) {
                Toast.makeText(this, "Não foi possível ler o backup.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != PICK_PROFILE_PHOTO || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (data.getFlags() != 0) {
                getContentResolver().takePersistableUriPermission(uri, data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
            }
        } catch(Exception ignored) {}
        final String value = uri.toString().replace("\\", "\\\\").replace("'", "\\'");
        if (web != null) {
            web.post(() -> web.evaluateJavascript("setProfilePhoto('" + value + "')", null));
        }
    }

    public class Bridge {
        private final Context ctx;
        Bridge(Context c) { ctx = c; }

        @JavascriptInterface public void saveConfig(String json) {
            prefs.edit().putString("config", json).apply();
        }

        @JavascriptInterface public void saveBackup(String json) {
            pendingBackup = json == null ? "{}" : json;
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, "WA-backup.json");
                    startActivityForResult(intent, CREATE_BACKUP);
                } catch (Exception e) {
                    Toast.makeText(ctx, "Não foi possível abrir o salvamento de backup.", Toast.LENGTH_LONG).show();
                }
            });
        }


        @JavascriptInterface public void restoreBackup() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain"});
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(intent, RESTORE_BACKUP);
                } catch (Exception e) {
                    Toast.makeText(ctx, "Não foi possível abrir os arquivos.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void restoreNativeData(String configJson, String historyJson) {
            try {
                new JSONObject(configJson);
                prefs.edit().putString("config", configJson).putString("history", historyJson == null ? "[]" : historyJson).apply();
            } catch (Exception e) {
                prefs.edit().putString("history", "[]").apply();
            }
        }

        @JavascriptInterface public String getConfig() {
            return prefs.getString("config", "{}");
        }

        @JavascriptInterface public String getHistory() {
            return prefs.getString("history", "[]");
        }

        @JavascriptInterface public void clearHistory() {
            prefs.edit().putString("history", "[]").apply();
        }


        @JavascriptInterface public boolean isNotificationAccessGranted() {
            try {
                String enabled = Settings.Secure.getString(ctx.getContentResolver(), "enabled_notification_listeners");
                if (enabled == null) return false;
                String pkg = ctx.getPackageName();
                return enabled.contains(pkg);
            } catch(Exception e) {
                return false;
            }
        }

        @JavascriptInterface public void openNotificationAccess() {
            try {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            } catch(Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }

        @JavascriptInterface public String getChosenRingtone(String category) { return prefs.getString("ringtone_" + safeRingtoneCategory(category), ""); }
        private String safeRingtoneCategory(String category) { return ("important".equals(category) || "noanswer".equals(category)) ? category : "response"; }
        @JavascriptInterface public void chooseNotificationSound(String category) {
            final String cat = safeRingtoneCategory(category);
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER);
                    intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_NOTIFICATION);
                    intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, "Escolher som de " + ("important".equals(cat) ? "alerta importante" : "notificação"));
                    intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true);
                    intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
                    String existing = prefs.getString("ringtone_" + cat, "");
                    if (!existing.isEmpty()) intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(existing));
                    pendingRingtoneCategory = cat;
                    startActivityForResult(intent, PICK_RINGTONE);
                } catch (Exception e) { Toast.makeText(ctx, "Não foi possível abrir os sons de notificação do celular.", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void chooseProfilePhoto() {
            try {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_PROFILE_PHOTO);
            } catch(Exception e) {
                try {
                    Intent fallback = new Intent(Intent.ACTION_PICK);
                    fallback.setType("image/*");
                    startActivityForResult(fallback, PICK_PROFILE_PHOTO);
                } catch(Exception ignored) {}
            }
        }

        @JavascriptInterface public void toast(String msg) {
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
        }
        private void playPreview(int soundId, int volume, int repeats) {
            try {
                final int safeVolume = Math.max(0, Math.min(100, volume));
                if (safeVolume == 0) { runOnUiThread(() -> Toast.makeText(ctx, "Volume está em 0%. Aumente o volume para ouvir o teste.", Toast.LENGTH_SHORT).show()); return; }
                final android.media.MediaPlayer[] holder = {new android.media.MediaPlayer()};
                // AudioAttributes precisa ser configurado antes de setDataSource/prepare.
                // MediaPlayer.create() já prepara o player e pode fazer esta configuração falhar.
                if (Build.VERSION.SDK_INT >= 21) {
                    holder[0].setAudioAttributes(new android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                } else { holder[0].setAudioStreamType(android.media.AudioManager.STREAM_ALARM); }
                try (android.content.res.AssetFileDescriptor afd = ctx.getResources().openRawResourceFd(soundResource(soundId))) {
                    if (afd == null) throw new java.io.IOException("Arquivo de áudio indisponível");
                    holder[0].setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                }
                holder[0].setOnPreparedListener(mp -> {
                    float v = safeVolume / 100f;
                    mp.setVolume(v, v);
                    final int[] played = {0};
                    mp.setOnCompletionListener(done -> {
                        played[0]++;
                        if (played[0] < Math.max(1, repeats)) {
                            try { done.seekTo(0); done.start(); } catch (Exception e) { try { done.release(); } catch(Exception ignored) {} }
                        } else { try { done.release(); } catch(Exception ignored) {} }
                    });
                    mp.setOnErrorListener((player, what, extra) -> { try { player.release(); } catch(Exception ignored) {} return true; });
                    mp.start();
                });
                holder[0].setOnErrorListener((mp, what, extra) -> { try { mp.release(); } catch(Exception ignored) {} return true; });
                holder[0].prepareAsync();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(ctx, "Falha ao reproduzir o som. Confira o volume do celular.", Toast.LENGTH_SHORT).show());
            }
        }

        @JavascriptInterface public void testImportantAlert(String contact, String incoming, int volume, int soundId) {
            try {
                android.app.NotificationManager nm=(android.app.NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
                if(nm!=null) {
                    String channelId="wa_important_attention_v1";
                    if(Build.VERSION.SDK_INT>=26){android.app.NotificationChannel ch=new android.app.NotificationChannel(channelId,"Alertas importantes do WA",android.app.NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Mensagens que precisam de atenção");ch.setSound(null,null);nm.createNotificationChannel(ch);}
                    android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(ctx,channelId):new android.app.Notification.Builder(ctx);
                    String body=(contact==null?"Cliente":contact)+" enviou: "+(incoming==null?"":incoming);
                    b.setSmallIcon(com.autoatendimento.app.R.drawable.icon_192).setContentTitle("Uma mensagem precisa atenção").setContentText(body).setStyle(new android.app.Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setPriority(android.app.Notification.PRIORITY_HIGH).setCategory(android.app.Notification.CATEGORY_MESSAGE);
                    nm.notify((int)(System.currentTimeMillis()&0x7fffffff),b.build());
                }
            } catch(Exception ignored) {}
            playConfiguredPreview("important", 15 + Math.max(1, Math.min(10, soundId)), volume, 3);
        }
        @JavascriptInterface public void testNoAnswerSound(int soundId, int volume) { playConfiguredPreview("noanswer", Math.max(1, Math.min(10, soundId)), volume, 2); }
        @JavascriptInterface public void testResponseSound(int soundId, int volume) { playConfiguredPreview("response", Math.max(1, Math.min(10, soundId)), volume, 2); }
        private void playConfiguredPreview(String category, int soundId, int volume, int repeats) {
            String chosen = prefs.getString("ringtone_" + category, "");
            if (chosen == null || chosen.isEmpty()) { playPreview(soundId, volume, repeats); return; }
            try {
                int safeVolume=Math.max(0,Math.min(100,volume)); if(safeVolume==0)return;
                final MediaPlayer mp=new MediaPlayer();
                if(Build.VERSION.SDK_INT>=21) mp.setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                mp.setDataSource(ctx, Uri.parse(chosen));
                mp.setOnPreparedListener(player->{float v=safeVolume/100f;player.setVolume(v,v);final int[] count={0};player.setOnCompletionListener(done->{count[0]++;if(count[0]<Math.max(1,repeats)){try{done.seekTo(0);done.start();}catch(Exception e){try{done.release();}catch(Exception ignored){}}}else try{done.release();}catch(Exception ignored){}});player.start();});
                mp.setOnErrorListener((player,what,extra)->{try{player.release();}catch(Exception ignored){}return true;});mp.prepareAsync();
            } catch(Exception e) { playPreview(soundId,volume,repeats); }
        }

        private int soundResource(int soundId) {
            switch(soundId) {
                case 1: return com.autoatendimento.app.R.raw.alerta1;
                case 2: return com.autoatendimento.app.R.raw.alerta2;
                case 3: return com.autoatendimento.app.R.raw.alerta3;
                case 4: return com.autoatendimento.app.R.raw.alerta4;
                case 5: return com.autoatendimento.app.R.raw.alerta5;
                case 6: return com.autoatendimento.app.R.raw.alerta6;
                case 7: return com.autoatendimento.app.R.raw.alerta7;
                case 8: return com.autoatendimento.app.R.raw.alerta8;
                case 9: return com.autoatendimento.app.R.raw.alerta9;
                case 10: return com.autoatendimento.app.R.raw.alerta10;
                case 11: return com.autoatendimento.app.R.raw.alerta11;
                case 12: return com.autoatendimento.app.R.raw.alerta12;
                case 13: return com.autoatendimento.app.R.raw.alerta13;
                case 14: return com.autoatendimento.app.R.raw.alerta14;
                case 15: return com.autoatendimento.app.R.raw.alerta15;
                case 16: return com.autoatendimento.app.R.raw.alerta16;
                case 17: return com.autoatendimento.app.R.raw.alerta17;
                case 18: return com.autoatendimento.app.R.raw.alerta18;
                case 19: return com.autoatendimento.app.R.raw.alerta19;
                case 20: return com.autoatendimento.app.R.raw.alerta20;
                case 21: return com.autoatendimento.app.R.raw.alerta21;
                case 22: return com.autoatendimento.app.R.raw.alerta22;
                case 23: return com.autoatendimento.app.R.raw.alerta23;
                case 24: return com.autoatendimento.app.R.raw.alerta24;
                case 25: return com.autoatendimento.app.R.raw.alerta25;
                case 26: return com.autoatendimento.app.R.raw.alerta26;
                case 27: return com.autoatendimento.app.R.raw.alerta27;
                case 28: return com.autoatendimento.app.R.raw.alerta28;
                case 29: return com.autoatendimento.app.R.raw.alerta29;
                case 30: return com.autoatendimento.app.R.raw.alerta30;
                case 31: return com.autoatendimento.app.R.raw.alerta31;
                case 32: return com.autoatendimento.app.R.raw.alerta32;
                case 33: return com.autoatendimento.app.R.raw.alerta33;
                case 34: return com.autoatendimento.app.R.raw.alerta34;
                case 35: return com.autoatendimento.app.R.raw.alerta35;
                case 36: return com.autoatendimento.app.R.raw.alerta36;
                case 37: return com.autoatendimento.app.R.raw.alerta37;
                case 38: return com.autoatendimento.app.R.raw.alerta38;
                case 39: return com.autoatendimento.app.R.raw.alerta39;
                case 40: return com.autoatendimento.app.R.raw.alerta40;
                case 41: return com.autoatendimento.app.R.raw.alerta41;
                case 42: return com.autoatendimento.app.R.raw.alerta42;
                case 43: return com.autoatendimento.app.R.raw.alerta43;
                case 44: return com.autoatendimento.app.R.raw.alerta44;
                case 45: return com.autoatendimento.app.R.raw.alerta45;
                default: return com.autoatendimento.app.R.raw.alerta1;
            }
        }

    }
}

# WA Autoatendimento V16.2.7 — Pacotes de som distintos

Projeto Android para geração do APK pelo GitHub Actions.

## Novidades desta versão
- 10 sons suaves compartilhados por resposta concluída e sem resposta, mais 10 sons de alerta importante redesenhados em três famílias sonoras claramente diferentes:
  - **Resposta (1–15):** uma única nota suave por reprodução.
  - **Alerta importante (16–30):** alarmes mais fortes, pulsantes e urgentes; a rotina de alerta importante reproduz o som três vezes.
  - **Sem resposta (31–45):** sinais graves, arredondados e discretos, diferentes dos sons de resposta e dos alarmes.
- Os 45 arquivos estão disponíveis como recursos nativos Android (`app/src/main/res/raw`) e também incorporados no `index.html`, para que a prévia não dependa de uma pasta externa `sounds`.
- Identificador do aplicativo mantido: `com.autoatendimento.app`.
- Versão: `16.2.7-sons-distintos` (versionCode 22).

## Gerar APK
1. Envie o conteúdo deste ZIP para a raiz do repositório GitHub, substituindo os arquivos anteriores.
2. Abra **Actions**.
3. Execute **Gerar APK WA Autoatendimento**.
4. Baixe o artefato `WA-Autoatendimento-APK-debug` quando o fluxo terminar.

O APK ainda precisa ser gerado pelo GitHub Actions e instalado para confirmar o comportamento de áudio no aparelho.


## Seleção de som do celular (16.2.7)
Foi adicionado um botão em cada categoria para abrir o seletor nativo de toques de notificação do Android. A escolha é guardada por categoria e usada na reprodução real; se nenhum toque do celular for escolhido, o app mantém os sons internos.

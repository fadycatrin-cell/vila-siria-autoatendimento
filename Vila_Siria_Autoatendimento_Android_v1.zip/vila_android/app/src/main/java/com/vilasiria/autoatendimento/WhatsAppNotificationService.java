package com.vilasiria.autoatendimento;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.text.Normalizer;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

public class WhatsAppNotificationService extends NotificationListenerService {
    private static final String WA = "com.whatsapp";
    private static final String WAB = "com.whatsapp.w4b";
    private SharedPreferences prefs;
    private long lastReplyAt = 0;
    private String lastReplyKey = "";

    @Override public void onCreate() { super.onCreate(); prefs = getSharedPreferences("auto_config", MODE_PRIVATE); }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!WA.equals(sbn.getPackageName()) && !WAB.equals(sbn.getPackageName())) return;
        String text = extractText(sbn.getNotification());
        if (text.trim().isEmpty()) return;
        JSONObject cfg;
        try { cfg = new JSONObject(prefs.getString("config", "{}")); } catch(Exception e) { return; }
        if (!cfg.optBoolean("active", false)) return;

        String title = sbn.getNotification().extras != null ? String.valueOf(sbn.getNotification().extras.getCharSequence(Notification.EXTRA_TITLE, "")) : "";
        String dedupe = title + "|" + text;
        long now = System.currentTimeMillis();
        if (dedupe.equals(lastReplyKey) && now-lastReplyAt < 12000) return;

        String reply = chooseReply(cfg, text);
        if (reply == null || reply.trim().isEmpty()) return;
        if (sendReply(sbn.getNotification(), reply)) { lastReplyKey=dedupe; lastReplyAt=now; }
    }

    private String extractText(Notification n) {
        Bundle e=n.extras; if(e==null)return "";
        CharSequence cs=e.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if(cs==null) cs=e.getCharSequence(Notification.EXTRA_TEXT);
        return cs==null?"":cs.toString();
    }

    private String chooseReply(JSONObject c, String msg) {
        // Horário: o painel grava schedule como objeto dia -> [[inicio,fim],...].
        if (c.optBoolean("afterHoursEnabled", true) && !isOpenNow(c.optJSONObject("schedule")))
            return c.optString("afterHours", "Olá! 😊 No momento estamos fora do nosso horário de funcionamento.");
        String n=norm(msg);
        JSONArray rules=c.optJSONArray("keywords");
        if(rules!=null) for(int i=0;i<rules.length();i++) try {
            JSONObject r=rules.getJSONObject(i); JSONArray keys=r.optJSONArray("k");
            if(keys!=null) for(int j=0;j<keys.length();j++) if(n.contains(norm(keys.optString(j)))) return r.optString("r","");
            else if(n.contains(norm(r.optString("k")))) return r.optString("r","");
        } catch(Exception ignored){}
        return c.optString("handoff", "Não encontrei uma resposta cadastrada para essa mensagem. 😊");
    }

    private boolean isOpenNow(JSONObject schedule) {
        if(schedule==null)return true;
        String[] days={"domingo","segunda","terca","quarta","quinta","sexta","sabado"};
        java.util.Calendar cal=java.util.Calendar.getInstance(); int day=cal.get(java.util.Calendar.DAY_OF_WEEK)-1;
        String key=days[day]; JSONArray periods=schedule.optJSONArray(key); if(periods==null||periods.length()==0)return false;
        int mins=cal.get(java.util.Calendar.HOUR_OF_DAY)*60+cal.get(java.util.Calendar.MINUTE);
        for(int i=0;i<periods.length();i++) try {JSONArray p=periods.getJSONArray(i); int a=toMin(p.getString(0)), b=toMin(p.getString(1)); if(b<=a ? (mins>=a||mins<b) : (mins>=a&&mins<b)) return true;}catch(Exception ignored){}
        return false;
    }
    private int toMin(String s){String[] x=s.split(":");return Integer.parseInt(x[0])*60+Integer.parseInt(x[1]);}
    private String norm(String s){return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(java.util.Locale.ROOT).trim();}

    private boolean sendReply(Notification n, String reply) {
        if(n.actions==null)return false;
        for(Notification.Action a:n.actions){
            RemoteInput[] ris=a.getRemoteInputs(); if(ris==null||ris.length==0)continue;
            Intent intent=new Intent(); Bundle results=new Bundle();
            for(RemoteInput ri:ris) results.putCharSequence(ri.getResultKey(), reply);
            RemoteInput.addResultsToIntent(ris,intent,results);
            try { a.actionIntent.send(this,0,intent); return true; } catch(Exception ignored) {}
        }
        return false;
    }
}

# Vila Síria Autoatendimento — Android v1

Projeto Android baseado na última versão Web v3, agora empacotada no app. Não usa Supabase: configurações ficam no aparelho.

## O que o app faz
- Painel de configurações em WebView, baseado no index.html da v3.
- Ativar/desativar autoatendimento.
- Mensagem fora do horário.
- Palavras/frases-chave com várias chaves por regra.
- Edição das regras.
- Horários e bairros/taxas locais.
- Serviço Android NotificationListenerService preparado para WhatsApp/WhatsApp Business.
- Resposta pela ação de resposta rápida da notificação, quando o WhatsApp disponibilizar essa ação.

## Gerar APK
1. Instale o Android Studio.
2. Abra a pasta `VilaSiriaAutoatendimento`.
3. Espere o Gradle sincronizar e instale o Android SDK solicitado.
4. Menu **Build > Build APK(s)**.
5. O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Instale no celular.
7. Abra o app, ative o Autoatendimento e permita o **Acesso às notificações** nas configurações do Android.

## Observação importante
O Android/WhatsApp pode mudar o formato das notificações e as ações disponíveis. A resposta automática só é possível quando a notificação do WhatsApp expõe uma ação de resposta (`RemoteInput`). Teste primeiro com uma conversa real.

# Vila Síria Autoatendimento — Android v2

Versão corrigida do aplicativo de autoatendimento do Vila Síria.

## Correções desta versão
- Anti-duplicação das respostas do WhatsApp.
- Botões **Editar** funcionando no WebView.
- **Testar resposta** funcionando no WebView.
- Histórico real dos atendimentos automáticos, com contato, mensagem recebida, resposta e data/hora.
- Histórico armazenado no Android e exibido no painel.
- Botão **Limpar histórico** limpa o histórico do painel e do Android.
- Mantidos WhatsApp e WhatsApp Business, regras por palavras/frases, horário e configuração local.
- Não usa Supabase e não usa IA.

## Gerar APK
Use o workflow do GitHub Actions já existente no repositório. O APK de debug será criado em:
`app/build/outputs/apk/debug/app-debug.apk`

Depois de instalar a V2, abra o aplicativo, mantenha o autoatendimento ativo e confirme o **Acesso às notificações**.

package com.autoatendimento.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.widget.Toast;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.View;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PICK_PROFILE_PHOTO = 1001;
    private static final int CREATE_BACKUP = 1002;
    private static final int RESTORE_BACKUP = 1003;
    private String pendingBackup = "";
    private WebView web;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("auto_config", MODE_PRIVATE);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        // O Android moderno pode desenhar o WebView por baixo da barra de status.
        // Reservamos o espaço da barra para que o topo do Autoatendimento não fique escondido.
        int statusBarId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarId > 0) {
            int statusBarHeight = getResources().getDimensionPixelSize(statusBarId);
            web.setPadding(0, statusBarHeight, 0, 0);
            web.setClipToPadding(false);
        }
        getWindow().setStatusBarColor(Color.rgb(18, 140, 90));
        getWindow().setNavigationBarColor(Color.rgb(7, 94, 84));
        // Necessário para alert(), prompt() e confirm() funcionarem dentro do WebView.
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (java.io.OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) out.write(pendingBackup.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                Toast.makeText(this, "Backup WA salvo.", Toast.LENGTH_LONG).show();
            } catch (Exception e) { Toast.makeText(this, "Não foi possível salvar o backup.", Toast.LENGTH_LONG).show(); }
            pendingBackup = "";
            return;
        }
        if (requestCode == RESTORE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
                if (in == null) throw new java.io.IOException("Arquivo indisponível");
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                byte[] bytes = new byte[8192]; int count;
                while ((count = in.read(bytes)) != -1) buffer.write(bytes, 0, count);
                String json = new String(buffer.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
                if (web != null) web.post(() -> web.evaluateJavascript("restoreBackupFromAndroid(" + JSONObject.quote(json) + ")", null));
            } catch (Exception e) {
                Toast.makeText(this, "Não foi possível ler o backup.", Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != PICK_PROFILE_PHOTO || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (data.getFlags() != 0) {
                getContentResolver().takePersistableUriPermission(uri, data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
            }
        } catch(Exception ignored) {}
        final String value = uri.toString().replace("\\", "\\\\").replace("'", "\\'");
        if (web != null) {
            web.post(() -> web.evaluateJavascript("setProfilePhoto('" + value + "')", null));
        }
    }

    public class Bridge {
        private final Context ctx;
        Bridge(Context c) { ctx = c; }

        @JavascriptInterface public void saveConfig(String json) {
            prefs.edit().putString("config", json).apply();
        }

        @JavascriptInterface public void saveBackup(String json) {
            pendingBackup = json == null ? "{}" : json;
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, "WA-backup.json");
                    startActivityForResult(intent, CREATE_BACKUP);
                } catch (Exception e) {
                    Toast.makeText(ctx, "Não foi possível abrir o salvamento de backup.", Toast.LENGTH_LONG).show();
                }
            });
        }


        @JavascriptInterface public void restoreBackup() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(intent, RESTORE_BACKUP);
                } catch (Exception e) {
                    Toast.makeText(ctx, "Não foi possível abrir os arquivos.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void restoreNativeData(String configJson, String historyJson) {
            try {
                new JSONObject(configJson);
                prefs.edit().putString("config", configJson).putString("history", historyJson == null ? "[]" : historyJson).apply();
            } catch (Exception e) {
                prefs.edit().putString("history", "[]").apply();
            }
        }

        @JavascriptInterface public String getConfig() {
            return prefs.getString("config", "{}");
        }

        @JavascriptInterface public String getHistory() {
            return prefs.getString("history", "[]");
        }

        @JavascriptInterface public void clearHistory() {
            prefs.edit().putString("history", "[]").apply();
        }


        @JavascriptInterface public boolean isNotificationAccessGranted() {
            try {
                String enabled = Settings.Secure.getString(ctx.getContentResolver(), "enabled_notification_listeners");
                if (enabled == null) return false;
                String pkg = ctx.getPackageName();
                return enabled.contains(pkg);
            } catch(Exception e) {
                return false;
            }
        }

        @JavascriptInterface public void openNotificationAccess() {
            try {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            } catch(Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }

        @JavascriptInterface public void chooseProfilePhoto() {
            try {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_PROFILE_PHOTO);
            } catch(Exception e) {
                try {
                    Intent fallback = new Intent(Intent.ACTION_PICK);
                    fallback.setType("image/*");
                    startActivityForResult(fallback, PICK_PROFILE_PHOTO);
                } catch(Exception ignored) {}
            }
        }

        @JavascriptInterface public void toast(String msg) {
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
        }
        @JavascriptInterface public void testResponseSound(int soundId, int volume) {
            try {
                int resId = soundResource(soundId);
                MediaPlayer mp = MediaPlayer.create(ctx, resId);
                if (mp == null) return;
                float v = Math.max(0f, Math.min(1f, volume / 100f));
                mp.setVolume(v, v);
                mp.setOnCompletionListener(MediaPlayer::release);
                mp.start();
            } catch(Exception ignored) {}
        }

        private int soundResource(int soundId) {
            switch(soundId) {
                case 2: return com.autoatendimento.app.R.raw.alerta2;
                case 3: return com.autoatendimento.app.R.raw.alerta3;
                case 4: return com.autoatendimento.app.R.raw.alerta4;
                case 5: return com.autoatendimento.app.R.raw.alerta5;
                default: return com.autoatendimento.app.R.raw.alerta1;
            }
        }

    }
}

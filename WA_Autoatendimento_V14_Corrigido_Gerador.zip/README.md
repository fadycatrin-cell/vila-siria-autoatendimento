# WA Autoatendimento V14 — Layout e histórico de perguntas

Esta versão evolui o projeto V13 e inclui ajustes de interface e histórico:

- Tela inicial com título WA e subtítulo “Autoatendimento para WhatsApp”.
- Botões de ativação e permissão mais compactos.
- Navegação entre abas por toque na barra ou deslize horizontal na área de conteúdo, com sincronização da aba ativa.
- Remoção da seção de foto do perfil.
- Idiomas disponíveis: português, inglês, espanhol e francês; opção e textos em árabe removidos.
- Traduções para os principais textos, botões, configurações, horários, categorias e histórico.
- Nova seção “Histórico de perguntas”, que registra perguntas recebidas detectáveis nas notificações e as organiza por frequência.
- Possibilidade de reutilizar uma pergunta no grupo de uma categoria existente ou iniciar um novo grupo com ela.
- O histórico geral continua separado das entradas de perguntas, para não contar perguntas recebidas como falhas de respostas.
- Mantém horário de funcionamento, atraso, som, PIN, backup e restauração, categorias e regras de respostas.

## Observação sobre o histórico de perguntas

O Android só permite registrar o texto disponibilizado nas notificações do WhatsApp. Por isso, o histórico depende das notificações recebidas enquanto o autoatendimento está ativado e identifica perguntas por pontuação ou expressões interrogativas comuns.

## Compilação

Use Java 17 e Gradle 8.7 com `gradle assembleDebug`. O APK de debug será gerado em `app/build/outputs/apk/debug/app-debug.apk`. O `versionCode` foi aumentado para 7 e o `versionName` para 14.0.

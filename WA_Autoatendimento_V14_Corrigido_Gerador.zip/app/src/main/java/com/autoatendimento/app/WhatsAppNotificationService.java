package com.autoatendimento.app;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.MediaPlayer;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class WhatsAppNotificationService extends NotificationListenerService {
    private static final String WA = "com.whatsapp";
    private static final String WAB = "com.whatsapp.w4b";
    private static final String HISTORY_KEY = "history";
    private static final String STATE_KEY = "wa_automation_state_v13";
    private static final long DEDUPE_WINDOW_MS = 12000L;
    private static final long OUTGOING_IGNORE_MS = 30000L;
    private SharedPreferences prefs;
    private final Object lock = new Object();
    private final LinkedHashMap<String, Long> recentProcessed = new LinkedHashMap<>();
    private final LinkedHashMap<String, Long> recentOutgoing = new LinkedHashMap<>();

    @Override public void onCreate() { super.onCreate(); prefs = getSharedPreferences("auto_config", MODE_PRIVATE); }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!WA.equals(sbn.getPackageName()) && !WAB.equals(sbn.getPackageName())) return;
        Notification notification = sbn.getNotification();
        if (isGroupConversation(notification)) return;
        String text = extractText(notification);
        if (text.trim().isEmpty()) return;
        JSONObject cfg;
        try { cfg = new JSONObject(prefs.getString("config", "{}")); } catch(Exception e) { return; }
        if (!cfg.optBoolean("active", false)) return;
        String title = "";
        if (notification.extras != null) title = String.valueOf(notification.extras.getCharSequence(Notification.EXTRA_TITLE, ""));
        final long now = System.currentTimeMillis();
        final String normalizedText = norm(text);
        final String normalizedTitle = norm(title);
        synchronized (lock) {
            cleanup(recentOutgoing, now, OUTGOING_IGNORE_MS);
            if (recentOutgoing.containsKey(sbn.getPackageName() + "|" + normalizedText)) return;
            cleanup(recentProcessed, now, DEDUPE_WINDOW_MS);
            String k1 = sbn.getPackageName() + "|" + sbn.getKey() + "|" + normalizedText;
            String k2 = sbn.getPackageName() + "|" + normalizedTitle + "|" + normalizedText;
            if (recentProcessed.containsKey(k1) || recentProcessed.containsKey(k2)) return;
            recentProcessed.put(k1, now); recentProcessed.put(k2, now);
        }
        String contactKey = sbn.getPackageName() + "|" + normalizedTitle;
        if (isQuestionMessage(text)) appendQuestionHistory(title, text);
        ReplyDecision decision = chooseReply(cfg, text, contactKey, now);
        if (decision == null || decision.reply == null || decision.reply.trim().isEmpty()) return;
        final String reply = decision.reply;
        final int delaySeconds = Math.max(0, Math.min(60, cfg.optInt("replyDelaySeconds", 0)));
        final String contact = title;
        final String originalText = text;
        final String packageName = sbn.getPackageName();
        Runnable sendTask = () -> {
            boolean sent = sendReply(notification, reply);
            if (sent) {
                synchronized (lock) { recentOutgoing.put(packageName + "|" + norm(reply), System.currentTimeMillis()); }
                if (cfg.optBoolean("soundEnabled", true)) playResponseSound(cfg.optInt("soundId", 1), cfg.optInt("soundVolume", 70));
                markSent(contactKey, decision, System.currentTimeMillis());
            }
            appendHistory(contact, originalText, sent ? reply : "Não foi possível enviar automaticamente pela notificação.", sent, delaySeconds, decision.reason);
        };
        if (delaySeconds > 0) new Handler(Looper.getMainLooper()).postDelayed(sendTask, delaySeconds * 1000L); else sendTask.run();
    }

    private static class ReplyDecision {
        String reply, categoryId, groupId, reason;
        boolean welcome, afterHours;
        ReplyDecision(String r, String c, String g, String why, boolean w, boolean a) { reply=r; categoryId=c; groupId=g; reason=why; welcome=w; afterHours=a; }
    }

    private ReplyDecision chooseReply(JSONObject c, String msg, String contact, long now) {
        boolean openNow = isOpenNow(c.optJSONObject("schedule"));
        if (!openNow) {
            if (!c.optBoolean("afterHoursEnabled", true)) return null;
            return new ReplyDecision(c.optString("afterHours", "Olá! No momento estamos fora do nosso horário de funcionamento."), "", "", "Mensagem fora do horário", false, true);
        }
        if (isLikelyOrder(msg)) return null;
        String n = norm(msg);
        JSONObject state = readState();
        JSONObject cs = state.optJSONObject(contact);
        if (cs == null) cs = new JSONObject();
        long lastIncoming = cs.optLong("lastIncomingAt", 0L);
        // Qualquer nova mensagem do cliente reinicia a contagem de inatividade.
        // Os grupos já respondidos só são liberados se o intervalo anterior já terminou.
        JSONArray categories = c.optJSONArray("categories");
        JSONObject categoryActivity = cs.optJSONObject("categoryActivity");
        if (categoryActivity == null) categoryActivity = new JSONObject();
        if (categories != null) {
            for (int i=0; i<categories.length(); i++) {
                JSONObject cat = categories.optJSONObject(i); if (cat == null) continue;
                String cid = cat.optString("id", "cat_"+i);
                long lastCatActivity = categoryActivity.optLong(cid, lastIncoming);
                long idleMs = Math.max(1, Math.min(1440, cat.optInt("inactivityMinutes", 30))) * 60000L;
                if (lastCatActivity > 0 && now - lastCatActivity >= idleMs) {
                    JSONObject responded = cs.optJSONObject("respondedGroups");
                    if (responded != null) responded.remove(cid);
                }
                try { categoryActivity.put(cid, now); } catch(Exception ignored) {}
            }
        }
        try { cs.put("lastIncomingAt", now); cs.put("categoryActivity", categoryActivity); } catch(Exception ignored) {}
        // A saudação tem seu próprio intervalo por contato, independente das categorias.
        if (c.optBoolean("welcomeEnabled", false) && isGreeting(n)) {
            long lastWelcome = cs.optLong("welcomeAt", 0L);
            long welcomeHours = Math.max(1, Math.min(24, c.optInt("welcomeIntervalHours", 6)));
            if (lastWelcome == 0L || now - lastWelcome >= welcomeHours * 3600000L) {
                try { cs.put("pendingWelcomeAt", now); state.put(contact, cs); writeState(state); } catch(Exception ignored) {}
                return new ReplyDecision(c.optString("welcome", ""), "", "", "Boas-vindas", true, false);
            }
        }
        if (categories != null) {
            JSONObject responded = cs.optJSONObject("respondedGroups");
            if (responded == null) responded = new JSONObject();
            for (int i=0; i<categories.length(); i++) {
                JSONObject cat = categories.optJSONObject(i); if (cat == null || !cat.optBoolean("enabled", true)) continue;
                String cid = cat.optString("id", "cat_"+i);
                JSONObject catResponded = responded.optJSONObject(cid);
                if (catResponded == null) catResponded = new JSONObject();
                JSONArray groups = cat.optJSONArray("groups"); if (groups == null) continue;
                for (int j=0; j<groups.length(); j++) {
                    JSONObject group = groups.optJSONObject(j); if (group == null || !group.optBoolean("enabled", true)) continue;
                    String gid = group.optString("id", "grp_"+j);
                    if (catResponded.optBoolean(gid, false)) continue;
                    JSONArray questions = group.optJSONArray("questions"); if (questions == null) continue;
                    boolean matched = false;
                    for (int q=0; q<questions.length(); q++) {
                        String question = norm(questions.optString(q));
                        if (!question.isEmpty() && (question.equals(n) || safeNearMatch(n, question))) { matched = true; break; }
                    }
                    if (matched) {
                        try { cs.put("respondedGroups", responded); state.put(contact, cs); writeState(state); } catch(Exception ignored) {}
                        return new ReplyDecision(group.optString("reply", ""), cid, gid, "Categoria: "+cat.optString("name", "")+" / "+group.optString("name", ""), false, false);
                    }
                }
            }
        }
        try { state.put(contact, cs); writeState(state); } catch(Exception ignored) {}
        return null;
    }

    private void markSent(String contact, ReplyDecision d, long now) {
        synchronized(lock) {
            JSONObject state = readState(); JSONObject cs = state.optJSONObject(contact); if (cs == null) cs = new JSONObject();
            try {
                if (d.welcome) { cs.put("welcomeAt", cs.optLong("pendingWelcomeAt", now)); cs.remove("pendingWelcomeAt"); }
                else if (!d.afterHours && d.categoryId != null && !d.categoryId.isEmpty()) {
                    JSONObject responded = cs.optJSONObject("respondedGroups"); if (responded == null) responded = new JSONObject();
                    JSONObject cat = responded.optJSONObject(d.categoryId); if (cat == null) cat = new JSONObject();
                    cat.put(d.groupId, true); responded.put(d.categoryId, cat); cs.put("respondedGroups", responded);
                }
                state.put(contact, cs); writeState(state);
            } catch(Exception ignored) {}
        }
    }

    private JSONObject readState() { try { return new JSONObject(prefs.getString(STATE_KEY, "{}")); } catch(Exception e) { return new JSONObject(); } }
    private void writeState(JSONObject state) {
        try {
            // Limita o armazenamento a 500 contatos, eliminando os mais antigos pela ordem de iteração.
            if (state.length() > 500) { ArrayList<String> keys = new ArrayList<>(); Iterator<String> it = state.keys(); while (it.hasNext()) keys.add(it.next()); for (int i=0; i<keys.size() && state.length()>500; i++) state.remove(keys.get(i)); }
            prefs.edit().putString(STATE_KEY, state.toString()).apply();
        } catch(Exception ignored) {}
    }

    private boolean isGreeting(String n) { return n.matches("(oi|ola|oie|bom dia|boa tarde|boa noite|hello|hey|ola tudo bem|oi tudo bem)"); }
    private boolean isLikelyOrder(String s) {
        String n = norm(s); String[] lines = s.split("\\n");
        int nonempty=0; for(String line:lines) if(!line.trim().isEmpty()) nonempty++;
        boolean money = s.matches("(?s).*(R\\$\\s?\\d|total\\s*:?|subtotal|pedido\\s*(n[ºo.]|realizado|confirmado)?).*" );
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b\\d+\\s?(x|un|unid|unidade|porcao)?\\b", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s); int quantities=0; while(m.find()) quantities++;
        boolean address = n.matches("(?s).*(rua|avenida|av|bairro|apto|apartamento|entregar em|casa \\d+).*" );
        return (money && (quantities>=2 || nonempty>=3)) || (quantities>=3 && nonempty>=2) || (address && quantities>=2) || (n.matches("(?s).*(meu pedido|resumo do pedido|pedido realizado).*" ) && s.length()>60);
    }
    private boolean safeNearMatch(String a, String b) {
        if (a == null || b == null || Math.min(a.length(), b.length()) < 12) return false;
        String[] aa=a.split(" "), bb=b.split(" "); if (Math.abs(aa.length-bb.length)>1) return false;
        return (double)editDistance(a,b)/Math.max(a.length(),b.length()) <= 0.08;
    }
    private int editDistance(String a,String b) {
        int[][] d=new int[a.length()+1][b.length()+1]; for(int i=0;i<=a.length();i++)d[i][0]=i; for(int j=0;j<=b.length();j++)d[0][j]=j;
        for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++)d[i][j]=Math.min(Math.min(d[i-1][j]+1,d[i][j-1]+1),d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1)); return d[a.length()][b.length()];
    }
    private boolean isGroupConversation(Notification n) { try { Bundle e=n.extras; return e!=null && e.getBoolean("android.isGroupConversation", false); } catch(Exception ignored) { return false; } }
    private String extractText(Notification n) {
        Bundle e=n.extras; if(e==null)return ""; CharSequence cs=e.getCharSequence(Notification.EXTRA_BIG_TEXT); if(cs==null)cs=e.getCharSequence(Notification.EXTRA_TEXT);
        if(cs==null){CharSequence[] lines=e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);if(lines!=null&&lines.length>0){StringBuilder b=new StringBuilder();for(CharSequence line:lines)if(line!=null){if(b.length()>0)b.append("\\n");b.append(line);}cs=b.toString();}}
        return cs==null?"":cs.toString();
    }
    private boolean isOpenNow(JSONObject schedule) {
        if(schedule==null)return true; String[] days={"domingo","segunda","terca","quarta","quinta","sexta","sabado"}; java.util.Calendar cal=java.util.Calendar.getInstance(); int day=cal.get(java.util.Calendar.DAY_OF_WEEK)-1; JSONArray periods=schedule.optJSONArray(days[day]); if(periods==null||periods.length()==0)return false;
        int mins=cal.get(java.util.Calendar.HOUR_OF_DAY)*60+cal.get(java.util.Calendar.MINUTE); for(int i=0;i<periods.length();i++)try{JSONArray p=periods.getJSONArray(i);int a=toMin(p.getString(0)),b=toMin(p.getString(1));if(b<=a?(mins>=a||mins<b):(mins>=a&&mins<b))return true;}catch(Exception ignored){} return false;
    }
    private int toMin(String s){String[] x=s.split(":");return Integer.parseInt(x[0])*60+Integer.parseInt(x[1]);}
    private String norm(String s) { return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).replaceAll("[!?.,;:¿¡]+"," ").replaceAll("[^\\p{L}\\p{N}\\s]"," ").replaceAll("\\s+"," ").trim(); }
    private boolean sendReply(Notification n,String reply){if(n.actions==null)return false;for(Notification.Action a:n.actions){RemoteInput[] ris=a.getRemoteInputs();if(ris==null||ris.length==0)continue;Intent intent=new Intent();Bundle results=new Bundle();for(RemoteInput ri:ris)results.putCharSequence(ri.getResultKey(),reply);RemoteInput.addResultsToIntent(ris,intent,results);try{a.actionIntent.send(this,0,intent);return true;}catch(Exception ignored){}}return false;}
    private void cleanup(Map<String,Long> map,long now,long ttl){Iterator<Map.Entry<String,Long>> it=map.entrySet().iterator();while(it.hasNext())if(now-it.next().getValue()>=ttl)it.remove();}
    private void playResponseSound(int soundId,int volume){try{int resId;switch(soundId){case 2:resId=R.raw.alerta2;break;case 3:resId=R.raw.alerta3;break;case 4:resId=R.raw.alerta4;break;case 5:resId=R.raw.alerta5;break;default:resId=R.raw.alerta1;}float v=Math.max(0f,Math.min(1f,volume/100f));if(v<=0f)return;MediaPlayer mp=MediaPlayer.create(this,resId);if(mp==null)return;mp.setVolume(v,v);mp.setOnCompletionListener(MediaPlayer::release);mp.start();}catch(Exception ignored){}}
    private boolean isQuestionMessage(String text) {
        String raw = text == null ? "" : text.trim();
        if (raw.isEmpty() || raw.length() > 500) return false;
        if (raw.contains("?") || raw.contains("¿") || raw.contains("؟")) return true;
        String n = norm(raw);
        return n.matches("(?s)^(voces|voce|tem|qual|quais|quanto|quantos|quantas|como|onde|quando|porque|por que|pode|podem|faz|fazem|aceita|aceitam|consigo|gostaria|queria|me manda|me envia|tem como|queria saber|gostaria de saber|pode me informar|me informa|me diz|quero saber|esta|estao|is|are|do|does|what|when|where|how|can|could|cuanto|cuantos|cuantas|donde|hacen|tienen|puedo|quel|quelle|quels|quelles|combien|comment|pouvez vous)([ ]|$).*);
    }
    private void appendQuestionHistory(String contact, String incoming) {
        synchronized (lock) {
            try {
                JSONArray old = new JSONArray(prefs.getString(HISTORY_KEY, "[]"));
                JSONArray out = new JSONArray();
                JSONObject item = new JSONObject(); item.put("type", "pergunta");
                item.put("contact", contact == null ? "" : contact);
                item.put("incoming", incoming == null ? "" : incoming);
                item.put("at", new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new java.util.Date()));
                out.put(item);
                for (int i = 0; i < Math.min(old.length(), 299); i++) out.put(old.get(i));
                prefs.edit().putString(HISTORY_KEY, out.toString()).apply();
            } catch (Exception ignored) { }
        }
    }
    private void appendHistory(String contact,String incoming,String reply,boolean sent,int delaySeconds,String reason){synchronized(lock){try{JSONArray old=new JSONArray(prefs.getString(HISTORY_KEY,"[]"));JSONArray out=new JSONArray();JSONObject item=new JSONObject();item.put("type","atendimento");item.put("contact",contact==null?"":contact);item.put("incoming",incoming==null?"":incoming);item.put("reply",reply==null?"":reply);item.put("sent",sent);item.put("reason",reason==null?"":reason);item.put("delaySeconds",delaySeconds);item.put("at",new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.getDefault()).format(new java.util.Date()));out.put(item);for(int i=0;i<Math.min(old.length(),299);i++)out.put(old.get(i));prefs.edit().putString(HISTORY_KEY,out.toString()).apply();}catch(Exception ignored){}}}
}

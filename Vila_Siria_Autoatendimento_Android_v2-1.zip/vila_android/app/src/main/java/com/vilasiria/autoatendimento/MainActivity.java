package com.vilasiria.autoatendimento;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("auto_config", MODE_PRIVATE);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        // Necessário para alert(), prompt() e confirm() funcionarem dentro do WebView.
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        private final Context ctx;
        Bridge(Context c) { ctx = c; }

        @JavascriptInterface public void saveConfig(String json) {
            prefs.edit().putString("config", json).apply();
        }

        @JavascriptInterface public String getConfig() {
            return prefs.getString("config", "{}");
        }

        @JavascriptInterface public String getHistory() {
            return prefs.getString("history", "[]");
        }

        @JavascriptInterface public void clearHistory() {
            prefs.edit().putString("history", "[]").apply();
        }

        @JavascriptInterface public void openNotificationAccess() {
            try {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            } catch(Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }

        @JavascriptInterface public void toast(String msg) {
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
        }
    }
}
